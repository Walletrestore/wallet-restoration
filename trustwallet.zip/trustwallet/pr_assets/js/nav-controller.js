const html = document.querySelector('html');
const nav_main = document.querySelector('#nav-main');
const nav_child = document.querySelector('#nav-child');
const mobile_theme_btn = document.querySelector('#mobile-theme-btn');
 
if (localStorage.getItem('@trust:theme')) {
    if (localStorage.getItem('@trust:theme') == 'dark') {
        html.classList.add('dark')
    }
} 

const changeThemeBg = () => {
    if (html.classList.contains('dark')) {
        html.classList.remove('dark');
        localStorage.removeItem('@trust:theme');
    } else {
        html.classList.add('dark')
        localStorage.setItem('@trust:theme', 'dark');
    }
}

const manipNav = () => {
    if (nav_main.getAttribute("data-isopen") == 'false') {
        nav_main.setAttribute("data-isopen", "true")
        nav_child.setAttribute("data-isopen", "true")
        mobile_theme_btn.setAttribute("data-isopen", "true")
        html.classList.add('overflow-hidden');
    } else {
        nav_main.setAttribute("data-isopen", "false")
        nav_child.setAttribute("data-isopen", "false")
        mobile_theme_btn.setAttribute("data-isopen", "false")
        html.classList.remove('overflow-hidden')
    }
}