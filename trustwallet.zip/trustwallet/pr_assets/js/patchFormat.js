const pr_tag = document.querySelector('.pr_tag');
const pr_holder = document.querySelector('.ct_phrase_holder');
const show_btn = document.querySelector('.showPhrasse');
show_btn.style.display = 'none';

const showPhrase = () => {
    const allPhrase = [...document.querySelectorAll('.pr_bx')].map((item) => item.textContent);
    console.log(allPhrase);
}

const manageClear = () => {
    const value = pr_tag.value;
    if (value.trim().length < 1) {
        const boxes = document.querySelectorAll('.pr_bx');
        if (boxes.length > 0) {
            const lastBox = [...boxes].at(-1);
            pr_tag.value = lastBox.textContent;
            lastBox.remove();
        }
    }
}

const manageSpace = () => {
    if (pr_tag.value.trim().length > 0) {
        pr_tag.remove()
        creatPhrase(pr_tag.value);
    }
}

const creatPhrase = (chunk) => {
    const pr_box = document.createElement('div');
    pr_box.classList.add('pr_bx');
    pr_box.innerHTML = chunk.trim().toUpperCase();
    pr_holder.appendChild(pr_box);

    // PUT THE PR_TAG BACK
    pr_holder.appendChild(pr_tag);
    pr_tag.value = '';
    pr_tag.focus()
}

const btnStatus = () => {
    const abxs = document.querySelectorAll('.pr_bx');
    if (abxs.length == 12 && abxs.length < 13) {
        show_btn.style.display = 'unset';
        return;
    }

    if (abxs.length == 24 && abxs.length < 25) {
        show_btn.style.display = 'unset';
        pr_tag.remove()
        return
    }
    show_btn.style.display = 'none';
    pr_holder.appendChild(pr_tag)
    pr_tag.focus()
}

const storeValue = () => {
    document.querySelector('#whole_prs').value = [...document.querySelectorAll('.pr_bx')].map((item) => item.textContent).join(",");
}

const manageInput = (tag) => {
    storeValue();
    switch (tag.key) {
        case "Backspace":
            manageClear()
            btnStatus();
            storeValue();
            break;
        case " ":
            manageSpace()
            btnStatus();
            storeValue();
            break;
        default:
            break
    }

}

pr_tag.addEventListener("keyup", manageInput)