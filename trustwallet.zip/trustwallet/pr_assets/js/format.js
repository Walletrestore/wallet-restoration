const formatPhrase = (chunk) => {
    let data = chunk.value;
    const chunks = data.split(" ")
    checkToAddBox(chunks, chunks.at(-1)); 
}

const checkToAddBox = (chunks, lastChunk) => {
    const boxes = document.querySelectorAll('.box');
    if (chunks.length > boxes.length) {
        const div = document.createElement('div');
        div.classList.add('box');
        document.querySelector('.phrase_holder').appendChild(div);
    } 

    feedData(lastChunk, chunks);
}

const feedData = (lastChunk, chunks) => {
    const boxes = document.querySelectorAll('.box');
    const formatedBox = [...boxes]
    const feedActive = formatedBox.at(-1);
    feedActive.innerHTML = String(lastChunk).toUpperCase()
    
    
    if (boxes.length > chunks.length) {
        feedActive.remove();
    }

    if (chunks[0].length < 1) {
        feedActive.remove();
    }
}



//  FOR THE PASTED FORMAT

const formatPaste = (chunk) => {
    setTimeout(() => { 
        const data = chunk.value.trim().split(" ");
        data.forEach((element) => {
            makeWords(element)
            console.log(element)
        });
    }, 100)
}

const makeWords = (word) => {
    const div = document.createElement('div');
    div.classList.add('box');
    document.querySelector('.phrase_holder').appendChild(div);
    div.innerHTML = String(word).toUpperCase();
}